﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kalendar_Termine
{
    public class Test
    {
        public string Namme { get; set; }
        public string NachName { get; set; }
    }
}
