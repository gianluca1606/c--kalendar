﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Kalendar_Termine
{
    /// <summary>
    /// Interaktionslogik für MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Kontaktdaten(object sender, RoutedEventArgs e)
        {
            KontaktdatenAnsicht Test = new KontaktdatenAnsicht();
            Test.Show();
        }

        private void Button_Terminansicht(object sender, RoutedEventArgs e)
        {
            Kalendaransicht Kalendaransicht = new Kalendaransicht();
            Kalendaransicht.Show();
        }

        private void Button_Ende(object sender, RoutedEventArgs e)
        {
            this.Close();
        } 
    }
}
