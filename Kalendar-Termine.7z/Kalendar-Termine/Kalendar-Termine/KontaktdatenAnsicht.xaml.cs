﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.OleDb;



namespace Kalendar_Termine
{
    /// <summary>
    /// Interaktionslogik für KontaktdatenAnsicht.xaml
    /// </summary>
    public partial class KontaktdatenAnsicht : Window
    {
        private DatabaseDataSet databaseDataSet;
        private DatabaseDataSetTableAdapters.PatientTableAdapter databaseDataSetPatientTableAdapter;
        private System.Windows.Data.CollectionViewSource patientViewSource;
       
        public KontaktdatenAnsicht()
        {

            InitializeComponent();
        }

     
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            databaseDataSet = ((Kalendar_Termine.DatabaseDataSet)(this.FindResource("databaseDataSet")));
            // Lädt Daten in Tabelle "Patient". Sie können diesen Code nach Bedarf ändern.
            databaseDataSetPatientTableAdapter = new Kalendar_Termine.DatabaseDataSetTableAdapters.PatientTableAdapter();
            databaseDataSetPatientTableAdapter.Fill(databaseDataSet.Patient);
            patientViewSource = ((System.Windows.Data.CollectionViewSource)(this.FindResource("patientViewSource")));
            patientViewSource.View.MoveCurrentToFirst();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OleDbCommandBuilder cmbPatient = new OleDbCommandBuilder(databaseDataSetPatientTableAdapter.Adapter);
                databaseDataSetPatientTableAdapter.Update(databaseDataSet);

                MessageBox.Show("Update erfolgreich");
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Update-Fehler:" + ex);
            } 
        }


        
    }
}
